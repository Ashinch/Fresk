# Fresk
An application that can take advantage of fragmented time to read and write.
