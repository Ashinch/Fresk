package com.ashinch.reader.data

data class Page(
        val chapterName: String,
        val page: String,
        val content: String
)