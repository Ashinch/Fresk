package com.ashinch.reader.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ashinch.reader.R
import com.ashinch.reader.data.Page
import com.ashinch.reader.view.JustifyTextView
import kotlinx.android.synthetic.main.item_page.view.*

class ReaderAdapter(private val pageList: List<Page>) : RecyclerView.Adapter<ReaderAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_page, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return pageList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemView.run {
            tvChapter.text = pageList.get(position).chapterName
            tvPage.text = pageList.get(position).page
            tvContent.text = pageList.get(position).content
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private var tvChapter: TextView? = null
        private var tvContent: JustifyTextView? = null
        private var tvTime: TextView? = null
        private var tvPage: TextView? = null

        init {
            tvChapter = itemView.findViewById(R.id.tvChapter)
            tvContent = itemView.findViewById(R.id.tvContent)
            tvTime = itemView.findViewById(R.id.tvTime)
            tvPage = itemView.findViewById(R.id.tvPage)
        }
    }
}