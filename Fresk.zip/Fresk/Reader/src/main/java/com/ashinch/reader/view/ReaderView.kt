package com.ashinch.reader.view

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.ashinch.reader.R
import com.ashinch.reader.adapter.ReaderAdapter
import com.ashinch.reader.data.Page
import com.yarolegovich.discretescrollview.DSVOrientation
import com.yarolegovich.discretescrollview.InfiniteScrollAdapter
import com.yarolegovich.discretescrollview.transform.ScaleTransformer
import kotlinx.android.synthetic.main.view_main.view.*

class ReaderView : LinearLayout {
    private var ctx: Context? = null
    private val data: List<Page> = listOf(Page("第一章", "1/1", "阿斯蒂芬撒旦法撒旦法萨芬"))

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        LayoutInflater.from(context).inflate(R.layout.view_main, this, true)

        with(scrollView!!) {
            setOrientation(DSVOrientation.HORIZONTAL)
            //addOnItemChangedListener(this)
            adapter = InfiniteScrollAdapter.wrap(ReaderAdapter(data))!!
            setItemTransformer(ScaleTransformer.Builder()
                    .setMaxScale(0.8f)
                    .build())
            scrollToPosition(0)
            //setItemTransitionTimeMillis()
        }

    }
}
