//package com.yarolegovich.discretescrollview.sample.shop
//
//import android.support.v7.widget.RecyclerView
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.ImageView
//
//import androidx.recyclerview.widget.RecyclerView
//
//import com.bumptech.glide.Glide
//import com.yarolegovich.discretescrollview.sample.R
//
//import sun.applet.AppletResourceLoader.getImage
//import sun.security.krb5.internal.KDCOptions.with
//
///**
// * Created by yarolegovich on 07.03.2017.
// */
//
//class ShopAdapter(private val data: List<Item>) : RecyclerView.Adapter<ShopAdapter.ViewHolder>() {
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        val inflater = LayoutInflater.from(parent.context)
//        val v = inflater.inflate(R.layout.item_shop_card, parent, false)
//        return ViewHolder(v)
//    }
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        Glide.with(holder.itemView.context)
//                .load(data[position].getImage())
//                .into(holder.image)
//    }
//
//    override fun getItemCount(): Int {
//        return data.size
//    }
//
//    internal inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//
//        private val image: ImageView
//
//        init {
//            image = itemView.findViewById(R.id.image) as ImageView
//        }
//    }
//}