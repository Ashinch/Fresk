package com.asterism.fresk.ui.activity;

import com.asterism.fresk.R;
import com.asterism.fresk.contract.IReadContract;
import com.asterism.fresk.presenter.ReadPresenter;

import java.util.List;

import nl.siegmann.epublib.domain.Book;

/**
 * 阅读Activity类，继承base基类且泛型为当前模块Presenter类型，并实现当前模块View接口
 *
 * @author Ashinch
 * @email Glaxyinfinite@outlook.com
 * @date on 2019-08-03 21:18
 */
public class ReadEpubActivity extends BaseActivity<IReadContract.Presenter>
        implements IReadContract.View {

//    @BindView(R.id.iv_book_pic)
//    ImageView ivBookPic;
//
//    @BindView(R.id.tv_book_name)
//    TextView tvBookName;
//
//    @BindView(R.id.tv_book_state)
//    TextView tvBookState;
//
//    @BindView(R.id.tv_chapter_num)
//    TextView tvChapterNum;
//
//    @BindView(R.id.tv_order)
//    TextView tvOrder;
//
//    @BindView(R.id.lv_chapter)
//    ListView lvChapter;

//    @BindView(R.id.align_tv)
//    AlignTextView alignTV;

//    @BindView(R.id.align_tv)
//    AlignTextView textView;

    private Book mBook;
    private List<String> mTocList;

    @Override
    protected int setLayoutId() {
        return R.layout.activity_read;
    }

    @Override
    protected IReadContract.Presenter setPresenter() {
        return new ReadPresenter();
    }

    @Override
    protected void initialize() {
        String path = getIntent().getStringExtra("path");
        if (path == null || path.isEmpty()) {
            showErrorToast("未找到文件！");
            finish();
        }
        mBook = mPresenter.getEpubBook("/storage/emulated/0/Download/三体三部曲_私人典藏版.epub",
                "UTF-8");
        mPresenter.getToc(mBook, new IReadContract.OnGetTocListener() {
            @Override
            public void onSuccess(List<String> tocString) {
                mTocList = tocString;
//                tvChapterNum.setText("共" + mTocList.size() + "章");
//                lvChapter.setAdapter(new ChapterListAdapter(ReadEpubActivity.this, mTocList));
            }

            @Override
            public void onError(String message) {
                showErrorToast("获取目录失败: " + message);
            }
        });

//        textView.getTextView().setText("asdfasdfasf阿斯顿发生答复");

        /**
         * 获取textview一行最大能显示几个字(需要在TextView测量完成之后)
         *
         * @param text     文本内容
         * @param paint    textview.getPaint()
         * @param maxWidth textview.getMaxWidth()/或者是指定的数值,如200dp
         */
//        private int getLineMaxNumber(String text, int maxWidth) {
//            if (null == text || "".equals(text)) {
//                return 0;
//            }
//            StaticLayout staticLayout = new StaticLayout(text, alignTV.getPaint(), maxWidth, Layout.Alignment.ALIGN_NORMAL
//                    , 1.0f, 0, false);
//            //获取第一行最后显示的字符下标
//            return staticLayout.getLineEnd(0);
//        }

        /**返回textview可显示完整的最大行数
         *
         * @param textView
         * @param MaxHeightDp
         * @param callBack
         */
//        private void getLine(final TextView textView, final int MaxHeightDp, final CallBack callBack) {
//            textView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
//                @Override
//                public void onGlobalLayout() {
//                    if(textView.getMeasuredHeight() != 0) {
//                        int lineHeight = textView.getMeasuredHeight()/ (textView.getLineCount() == 0 ? 1 : textView.getLineCount());
//                        if(lineHeight == 0) return;
//                        int maxLine = dip2px(MaxHeightDp)/lineHeight;
//                        textView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
//                        if(callBack != null) callBack.onSuccess(maxLine);
//                    }
//                }
//            });
//        }
    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }
}
